#ifndef OLED_H
#define OLED_H

// ============================================================================
// OLED ENABLE/DISABLE CONFIGURATION
// ============================================================================
// Comment out the next line to disable all OLED functionality
#define ENABLE_OLED 1

#if ENABLE_OLED
#include <U8g2lib.h>
#endif

#include "debug.h"

#define SDA_OLED     GPIO_NUM_5
#define SCL_OLED     GPIO_NUM_4
#define RST_OLED     GPIO_NUM_21
#define BUTTON_PIN   GPIO_NUM_0
#define VEXT_PIN     GPIO_NUM_36

#if ENABLE_OLED
/**
 * @brief The main U8G2 display object for a 128x64 SSD1306.
 *        Adjust the constructor as needed for your hardware/board.
 */
extern U8G2_SSD1306_128X64_NONAME_F_HW_I2C display;
#endif

/**
 * @brief Initialize the display (powering on, setting fonts, etc.).
 *        If OLED is disabled, this becomes a no-op.
 */
void setupDisplay();

/**
 * @brief Example functions to toggle external power if your board has it.
 *        If OLED is disabled, these become no-ops.
 */
void VextON();
void VextOFF();

/**
 * @brief Check if OLED functionality is enabled at compile time.
 */
bool isOLEDEnabled();

#endif
