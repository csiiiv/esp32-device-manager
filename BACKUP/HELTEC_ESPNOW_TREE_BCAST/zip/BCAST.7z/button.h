#ifndef BUTTON_H
#define BUTTON_H

#include <Arduino.h>

/**
 * @brief Enumeration for button events
 */
enum ButtonEvent {
    BUTTON_NONE,
    BUTTON_SHORT_PRESS,
    BUTTON_LONG_PRESS,
    BUTTON_DOUBLE_CLICK
};

/**
 * @brief Setup the button hardware with pull-up, etc.
 */
void setupButton(uint8_t pin);

/**
 * @brief Check the button each loop; returns the event if triggered.
 */
ButtonEvent checkButton();

#endif // BUTTON_H
