#include "button.h"
#include "debug.h"

#define MODULE_TITLE       "BTN"
#define MODULE_DEBUG_LEVEL 3
#define btnLog(msg,lvl) debugPrint(msg, MODULE_TITLE, lvl, MODULE_DEBUG_LEVEL)

static uint8_t buttonPin;
static bool lastState = HIGH; 
static unsigned long pressStart = 0;
static bool handled = false;
static const unsigned long LONG_PRESS_MS = 800; // 0.8 seconds

// Double-click detection
static unsigned long lastReleaseTime = 0;
static const unsigned long DOUBLE_CLICK_WINDOW_MS = 400; // 0.4 seconds

void setupButton(uint8_t pin){
    buttonPin = pin;
    pinMode(buttonPin, INPUT_PULLUP);
    btnLog("Button setup complete on pin=" + String(pin), 3); // INFO
}

ButtonEvent checkButton(){
    ButtonEvent ev = BUTTON_NONE;
    bool st = digitalRead(buttonPin);
    
    // Falling edge => press
    if(st==LOW && lastState==HIGH){
        pressStart=millis();
        handled=false;
        btnLog("Button pressed",4); // DEBUG
    }
    // while pressed
    if(st==LOW && !handled){
        unsigned long dur=millis()-pressStart;
        if(dur>=LONG_PRESS_MS){
            ev=BUTTON_LONG_PRESS;
            handled=true;
            btnLog("Long press detected",3); // INFO
        }
    }
    // Rising edge => release
    if(st==HIGH && lastState==LOW){
        unsigned long dur=millis()-pressStart;
        unsigned long now = millis();
        
        if(dur<LONG_PRESS_MS && !handled){
            // Check for double-click
            if (lastReleaseTime > 0 && (now - lastReleaseTime) <= DOUBLE_CLICK_WINDOW_MS) {
                ev = BUTTON_DOUBLE_CLICK;
                lastReleaseTime = 0; // Reset to prevent triple-click
                btnLog("Double-click detected", 3); // INFO
            } else {
                ev = BUTTON_SHORT_PRESS;
                lastReleaseTime = now; // Store time for potential double-click
                btnLog("Short press detected", 3); // INFO
            }
            handled = true;
        }
        btnLog("Button released", 4); // DEBUG
    }
    
    lastState=st;
    return ev;
}
